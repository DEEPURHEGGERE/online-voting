<html lang="en">
<head>
   
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Log In </title>
    <link href="css/responsive.css" rel="stylesheet" type="text/css">          
    <link rel="stylesheet" href="csss/style.css">

    
</head>
<body>
    <style>#dropbox{
    padding: 10px;
    border-radius: 5px;
    width: 12%;
    border: #0b0c0b;
}
#headersection{
    padding-top: 15px;
    font-family: cursive;
    color: red;
}
.form-sub {
  width: auto;
  display: inline-block;
  border: none;
  background:#00ec4f;
  color:black;
  padding: 10px;
  height: 50px;
  box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -moz-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -webkit-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -o-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -ms-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  margin-right: 5px; }
  .form-sub:hover {
    background-color: rgba(77, 84, 177, 0.804); }

.sub {
  width: 130px;
  border-radius: 25px;
  -moz-border-radius: 25px;
  -webkit-border-radius: 25px;
  -o-border-radius: 25px;
  -ms-border-radius: 25px;
  font-size: 23px;
  cursor: pointer; }
</style>
<br><a href="index.php"><button id="backbtn" class="form-sub sub">Back</button></a>
<center>
    <div id="headersection">
        
       <h1> Everyones vote MATTERS</h1>
       
    
       </div>
    
</center>

<div class="main">

    <div class="container">
        <div class="signup-content">
            <form action="api/login.php" method="post" id="signup-form" class="signup-form">
                <h2>Log In </h2>
                <div class="form-group">

             



                    <input type="text" class="form-input" name="usn" placeholder="enter the USN">
                    
                </div>
                <div class="form-group">
                    <input type="password" class="form-input" name="password" placeholder="enter the password">
            
                    
                  
                </div>
                <select id="dropbox" name="role" >
                    <option value="1"> voter
                    </option>
                    <option value="2"> Nominee</option>
                    </select><br><br><br><br><br><br><br><br><br><br><br><br>
                    <div class="form-group">
                        <input type="submit" name="login" id="submit" class="form-submit submit" value="Log In" />
                        
                    </div><br><br><br><br><br><br><br><br><br><br><br><br>
                     New user? <a href="routes/register.php" style="color:pink;">Register Here </a>




                     
                
            </form>
        </div>
    </div>

</div>


    </body>
    </html>
