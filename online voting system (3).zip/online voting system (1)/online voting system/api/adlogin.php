<?php
session_start();
include("connect.php");
$admin_id=$_POST['admin_id'];
$password=$_POST['password'];
$role=$_POST['role'];
$check= mysqli_query($connect,"SELECT * FROM admin WHERE admin_id='$admin_id' AND password='$password'");
if(mysqli_num_rows($check)>0){
    $userdata=mysqli_fetch_array($check);
    $groups= mysqli_query($connect,"SELECT *FROM user WHERE role=2 ");
    $groupsdata=mysqli_fetch_all($groups,MYSQLI_ASSOC);

    $_SESSION['userdata']=$userdata;
    $_SESSION['groupsdata']=$groupsdata;

    echo '
    <script>
window.location= "../routes/result.php";
    </script>
    ';

}
else{
    echo '
    <script>
    alert("invalid credentials! Enter valid data.");
window.location= "../adlin.php";
    </script>
    ';
}
?>
<?php/*
session_start();
include("connect.php");
$usn=$_POST['usn'];
$password=$_POST['password'];
$role=$_POST['role'];
$check= mysqli_query($connect,"SELECT * FROM user WHERE usn='$usn' AND password='$password' AND role='$role' ");
if(mysqli_num_rows($check)>0){
    $userdata=mysqli_fetch_array($check);
    $groups= mysqli_query($connect,"SELECT *FROM user WHERE role=2");
    $groupsdata=mysqli_fetch_all($groups,MYSQLI_ASSOC);

    $_SESSION['userdata']=$userdata;
    $_SESSION['groupsdata']=$groupsdata;

 
    echo '
    <script>
window.location= "../routes/result.php";
    </script>
    ';

}
else{
    echo '
    <script>
    alert("invalid credentials! Enter valid data.");
window.location= "../adlin.php";
    </script>
    ';
}*/