<?php
 include("connect.php");
 $name=$_POST['name'];
 $usn=$_POST['usn'];
 $password=$_POST['password'];
 $cpassword=$_POST['cpassword'];
 $address=$_POST['address'];
 $image= $_FILES['photo']['name'];
 $tmp_name= $_FILES['photo']['tmp_name'];
 $role=$_POST['role'];

 if($name=="" || $usn=="" || $password=="" || $cpassword=="" || $address=="" || $image=="" || $role==""){
    echo '
    <script>
    alert("Data NOT Entered,Retry");
window.location= "../routes/register.php";
    </script>
    ';
 }

 if($password==$cpassword){
     
    $vid=mysqli_query($connect,"SELECT *FROM user WHERE usn='$usn'");
    if(mysqli_num_rows($vid)==1){
    echo '
    <script>
    alert("voter-id already EXIST");
window.location= "../routes/register.php";
    </script>
    ';
    }
    move_uploaded_file($tmp_name, "../uploads/$image");
    $insert=mysqli_query($connect,"INSERT INTO user(name,usn,password,address,photo,role,status,votes) VALUES ('$name','$usn','$password','$address','$image','$role',0,0)");
     if($insert){
        echo '
        <script>
        alert("Registeration Succesful");
    window.location= "../";
        </script>
        ';
    }
    
   
    else{
        echo '
        <script>
        alert("Some error has occured!");
    window.location= "../routes/register.php";
        </script>
        ';
    }
}
 else{
    echo '
        <script>
        alert("password and confirm password does not match!");
    window.location= "../routes/register.php";
        </script>
        ';
    
    
    
 }
 
 
?>