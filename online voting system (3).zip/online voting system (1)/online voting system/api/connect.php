<?php
$connect = mysqli_connect("localhost" , "root","","voting") or die("conection failed");
if($connect){
    echo "Connected";
}
else{
    echo "Not connected";
}

?>