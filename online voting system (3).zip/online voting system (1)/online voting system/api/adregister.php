<?php
 include("connect.php");
 $name=$_POST['name'];
 $admin_id=$_POST['admin_id'];
 $password=$_POST['password'];
 $cpassword=$_POST['cpassword'];
 
/*
 if($name=="" || $admin_id=="" || $password=="" || $cpassword==""){
    echo '
    <script>
    alert("Data NOT Entered,Retry");
window.location= "../routes/adregister.php";
    </script>
    ';
 }*/

 if($password==$cpassword){
     
    $vid=mysqli_query($connect,"SELECT *FROM  admin  WHERE admin_id='$admin_id'");
    if(mysqli_num_rows($vid)==1){
    echo '
    <script>
    alert("voter-id already EXIST");
window.location= "../routes/adregister.php";
    </script>
    ';
    }
    
    $insert=mysqli_query($connect,"INSERT INTO admin(Name,admin_id,password) VALUES ('$name','$admin_id','$password')");
     if($insert){
        echo '
        <script>
        alert("Registeration Succesful");
    window.location= "../";
        </script>
        ';
    }
    
   
    else{
        echo '
        <script>
        alert("Some error has occured!");
    window.location= "../routes/adregister.php";
        </script>
        ';
    }
}
 else{
    echo '
        <script>
        alert("password and confirm password does not match!");
    window.location= "../routes/adregister.php";
        </script>
        ';
    
    
    
 }
 
 
?>