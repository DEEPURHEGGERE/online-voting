<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, maximum-scale=1">

	<title>Homepage</title>
	<link rel="icon" href="img/policelogo.jpg" type="image/jpg">
	<link rel="shortcut icon" href="img/policelogo.jpg" type="img/x-icon">

	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/font-awesome.css" rel="stylesheet" type="text/css">
	<link href="css/responsive.css" rel="stylesheet" type="text/css">
	<link href="css/magnific-popup.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" type="text/css">

	<script type="text/javascript" src="js/jquery.1.8.3.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/jquery-scrolltofixed.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.js"></script>
	<script type="text/javascript" src="js/wow.js"></script>
	<script type="text/javascript" src="js/classie.js"></script>
	<script type="text/javascript" src="js/magnific-popup.js"></script>
	<script src="contactform/contactform.js"></script>

	<!-- =======================================================
    Theme Name: Knight
    Theme URL: https://bootstrapmade.com/knight-free-bootstrap-theme/
    Author: BootstrapMade
    Author URL: https://bootstrapmade.com
	======================================================= -->

</head>

<body>
	<header class="header" id="header">
		<!--header-start-->
		<div class="container">
			<br><br><br><br><br><br><br><br><br><br><br>
			<h1 class="animated fadeInDown delay-07s">WELCOME TO ONLINE VOTING SYSTEM</h1>
			<ul class="we-create animated fadeInUp delay-1s">
				<br><li>The <b>BALLOT</b> Is Stronger Than The <b>BULLET</b></li>
			</ul>
			<a class="link animated fadeInUp delay-1s servicelink" href="lin.php">LOGIN NOW</a>
		</div>
	</header>
	<!--header-end-->

	<nav class="main-nav-outer" id="test">
		<!--main-nav-start-->
		<div class="container">
			<ul class="main-nav">
				<li><a href="#header">Home</a></li>
				<li><a href="lin.php">Login Now</a></li>
				<li><a href="routes/register.php">New Register</a></li>
				<li class="small-logo"><a href="#header"><img src="img/policelogo.png" height="70" width="90" alt=""></a></li>
				<li><a href="adlin.php">admine login</a></li>
				<li><a href="#client">Help</a></li>
				<li><a href="#contact">Contact</a></li>
			</ul>
			<a class="res-nav_click" href="#"><i class="fa fa-bars"></i></a>
		</div>
	</nav>
	<!--main-nav-end-->

	</section>
	<!--main-section-end-->



	<section class="main-section alab		<!--main-section alabaster-start-->
		<div class="container">
			<div class="row">
				<figure class="col-lg-5 col-sm-4 wow fadeInLeft">
				<br>	<img src="img/policelogo.png" alt=""  height="550" width="1200" >
				</figure>
				<div class="col-lg-7 col-sm-8 featured-work">
					<h2>CONDUCTIONS</h2><br><br><br>
					<div class="featured-box">
						<div class="featured-box-col1 wow fadeInRight delay-02s">
							<i class="fa fa-magic"></i>
						</div>
						<div class="featured-box-col2 wow fadeInRight delay-02s">
							<h3>Vice President Elections</h3><br><br><br>
							
					</div>
					<div class="featured-box">
						<div class="featured-box-col1 wow fadeInRight delay-04s">
							<i class="fa fa-gift"></i>
						</div>
						<div class="featured-box-col2 wow fadeInRight delay-04s">
							<h3>Class Representative Elections</h3><br><br>
							
						</div>
					</div>
					<div class="featured-box">
						<div class="featured-box-col1 wow fadeInRight delay-06s">
							<i class="fa fa-dashboard"></i>
						</div>
						<div class="featured-box-col2 wow fadeInRight delay-06s">
							<h3>Forum Representative Elections
</h3><br><br>
							
							
							
						</div>
					</div>
					<div class="featured-box">
						<div class="featured-box-col1 wow fadeInRight delay-02s">
							<i class="fa fa-magic"></i>
						</div>
						<div class="featured-box-col2 wow fadeInRight delay-02s">
							<h3>Treasurer Elections
</h3>
							
					</div>
					
					
					<a class="Learn-More" href="#">Learn More</a>
				</div>
			</div>
		</div>
	</section>

	<section class="business-talking">
		<!--business-talking-start-->
		<div class="container">
			<h2><b>Your Vote Matters !!!</b></h2>
		</div>
	</section>
	<br><br><br><br>
	<section class="main-section client-part" id="client">
		<!--main-section client-part-start-->
		<div class="container">
			
			<div class="row">
				<div class="col-lg-12">
					<h2 style="color: white;">STEPS TO VOTE</h2>
				</div>
			</div><br>
			
			<div>
			<h3 style="font-size:25px;px;  color: white;">1.Click on Log-in button ,Enter your usn ,password and press on Login.</h3>
			</div><br>
			<div>
			<h3 style="font-size:25px;px; color: white;">2.If not registered then register by clicking new register provide the required data and set password and register.</h3>
			</div><br>
			<div>
			<h3 style="font-size:25px;px;color: white;">3.Vote the person that you wanted to vote for.</h3>
			</div><br>
			<div>
			<h3 style="font-size:25px;px; color: white;">4.Logout by clicking on logout button.</h3>
			</div><br>
		</div>
	</section>
	<!--business-talking-end-->
	<div class="container">
		<section class="main-section contact" id="contact">

			<div class="row">
				<div class="col-lg-6 col-sm-7 wow fadeInLeft">
					<div class="contact-info-box address clearfix">
						<h3><i class=" icon-map-marker"></i>Name:</h3>
						<span>Akash K Chitragar,Darshan J Raichur
							  
						</span>
					</div>
					<div class="contact-info-box email clearfix">
						<h3><i class="fa fa-pencil"></i>USN:</h3>
						<span>4GM20CS006,4GM20CS029
						</span>
					</div>
					<div class="contact-info-box phone clearfix">
						<h3><i class="fa fa-phone"></i>Phone:</h3>
						<span>800364994,934225194</span>
					</div>
					
					<div class="contact-info-box hours clearfix">
						<h3><i class="fa fa-clock-o"></i>Topic:</h3>
						<span>DBMS mini project</span>
					</div>
					
				</div>
				<div class="col-lg-6 col-sm-5 wow fadeInUp delay-05s">
				
				</div>
			</div>
		</section>
	</div>
	<script type="text/javascript">
		$(document).ready(function(e) {

			$('#test').scrollToFixed();
			$('.res-nav_click').click(function() {
				$('.main-nav').slideToggle();
				return false

			});

      $('.Portfolio-box').magnificPopup({
        delegate: 'a',
        type: 'image'
      });

		});
	</script>

	<script>
		wow = new WOW({
			animateClass: 'animated',
			offset: 100
		});
		wow.init();
	</script>


	<script type="text/javascript">
		$(window).load(function() {

			$('.main-nav li a, .servicelink').bind('click', function(event) {
				var $anchor = $(this);

				$('html, body').stop().animate({
					scrollTop: $($anchor.attr('href')).offset().top - 102
				}, 1500, 'easeInOutExpo');
				/*
				if you don't want to use the easing effects:
				$('html, body').stop().animate({
					scrollTop: $($anchor.attr('href')).offset().top
				}, 1000);
				*/
				if ($(window).width() < 768) {
					$('.main-nav').hide();
				}
				event.preventDefault();
			});
		})
	</script>

	<script type="text/javascript">
		$(window).load(function() {


			var $container = $('.portfolioContainer'),
				$body = $('body'),
				colW = 375,
				columns = null;


			$container.isotope({
				// disable window resizing
				resizable: true,
				masonry: {
					columnWidth: colW
				}
			});

			$(window).smartresize(function() {
				// check if columns has changed
				var currentColumns = Math.floor(($body.width() - 30) / colW);
				if (currentColumns !== columns) {
					// set new column count
					columns = currentColumns;
					// apply width to container manually, then trigger relayout
					$container.width(columns * colW)
						.isotope('reLayout');
				}

			}).smartresize(); // trigger resize to set container width
			$('.portfolioFilter a').click(function() {
				$('.portfolioFilter .current').removeClass('current');
				$(this).addClass('current');

				var selector = $(this).attr('data-filter');
				$container.isotope({

					filter: selector,
				});
				return false;
			});

		});
	</script>

</body>

</html>
