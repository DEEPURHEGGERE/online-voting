<html>
<head>
    <title> online voting -Registration Form </title>
    

    
</head>
<body>
    <style>
         .form-sub {
  width: auto;
  display: inline-block;
  border: none;
  background:#00ec4f;
  color:black;
  padding: 10px;
  height: 50px;
  box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -moz-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -webkit-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -o-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -ms-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  margin-right: 5px; }
  .form-sub:hover {
    background-color: rgba(77, 84, 177, 0.804); }

.sub {
  width: 130px;
  border-radius: 25px;
  -moz-border-radius: 25px;
  -webkit-border-radius: 25px;
  -o-border-radius: 25px;
  -ms-border-radius: 25px;
  font-size: 23px;
  cursor: pointer; }
.form-submit {
  width: auto;
  display: inline-block;
  border: none;
  background:#d376f5;
  color:black;
  padding: 10px;
  height: 50px;
  box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -moz-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -webkit-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -o-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -ms-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  margin-right: 5px; }
  .form-submit:hover {
    background-color: #e6e6e6; }

.submit {
  width: 130px;
  border-radius: 25px;
  -moz-border-radius: 25px;
  -webkit-border-radius: 25px;
  -o-border-radius: 25px;
  -ms-border-radius: 25px;
  text-transform: uppercase;
  font-size: 15px;
  cursor: pointer; }
body{
    background-image: url("../images/bo.jpg");
    background-repeat: no-repeat;
    background-size: cover;
    
}     
#dropbox{
    padding: 10px;
    border-radius: 5px;
    width: 12%;
    border: #0b0c0b;
}
#logbt{
    padding: 8px;
    border-radius: 5px;
    background-color: rgb(111, 223, 245);
    color: rgb(13, 13, 13);
    font-size: 15px;
    width: 5%;
}

        input{
    padding: 5px;
    background-color:#eab9f9;
    border-radius: 5px;
    height: 40px;
  width: 210px; ;
  font-weight: bold;
  font-family: 'Poppins';
  font-size: 14px;
  
        }
        #address{
            height: 45px;
            width: 432px;
        }
        #imagepart{
            color: black;
            font-weight: bold;
  font-family: 'Poppins';
            font-size: 17px;
            background-color:#eab9f9;
            border: 1px solid black;
            border-radius: 5px;
            padding: 0px;
            height: 50px;
            width: 432px;
            
        }
        .signup-content {
  width: 540px;
  height: 575px;
  margin-right: 0px;
    background: rgba(77, 84, 177, 0.892);
   }
        #role{
            background-color: aliceblue;
            border: 1px solid black;
            font-size: 17px;
            background-color:#eab9f9;
            border-radius: 5px;
            padding: 2px;
            height: 40px;
            width: 432px;
            color:black;
        }
    
        #role select{
            border-radius: 5px;
            padding: 10px;
        }
        #al{
            font-weight: bold;
  font-family: 'Poppins';
            font-size: 18px;
            color: aliceblue;
        }
       
   /* h2 {
  line-height: 1.2;
  margin: 0;
  padding: 0;
  font-weight: bold;
  color: #fff;
  font-family: 'Poppins';
  font-size: 36px;
  margin-bottom: 10px; }*/
    </style>
     <a href="../"> <button id="backbtn" class="form-sub sub">Back</button></a>
    <center>
    <div id="headersection">
    
        
        <h1> Online voting system </h1>
       </div></center>
      
       <center>
    
    <div class="container">
    <div class="signup-content">
       
    <br><h2 style="color: #fff;font-family:'Poppins';margin-top: 10px;font-size: 27px;font-weight: bold; margin-bottom: 10px;">Registration</h>
    
    <form action="../api/register.php" method="POST" enctype="multipart/form-data">
    <br><input type="text" name="name" placeholder="Name">
    <input type="text" name="usn" placeholder="usn"><br><br>
    <input type="password" name="password" placeholder="Password">
    <input type="password" name="cpassword" placeholder="Confirm password"><br><br>
    <input id="address" type="text" name="address" placeholder="Address"><br><br>
    
    <div id="imagepart" >
        Upload image:  <input type="file" name="photo" >
    </div>
    
    <br>
    <div id="role">
        Select role: <select name="role">
            <option value="1">Voter</option>
            <option value="2">Nominee</option>
        </select>
    </div>
   
    <br>
    <button class="form-submit submit" > Register </button><br><br>
   <div id="al">Already user?<a href="../lin.php" style="color:pink;"> login here </a></div>
    </form>
</div>
    </div>
    </div>
</center>
</body>
</html>