
<?php
session_start();
/*if(!isset($_SESSION['userdata'])){
    header("location:../");
}*/
  $userdata = $_SESSION['userdata'];
  $groupsdata = $_SESSION['groupsdata'];

?>

<html>
<head>
    <title> online voting system-dashboard </title>
    
    
</head>
<body>
    <style>
        body{
    background-image: url("../images/bo.jpg");
    background-repeat: no-repeat;
    background-size: cover;
    
}
        .form-submit {
  width: auto;
  display: inline-block;
  border: none;
  
  color:black;
  padding: 10px;
  height: 50px;
  box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -moz-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -webkit-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -o-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  -ms-box-shadow: 0px 15px 9.9px 0.1px rgba(0, 0, 0, 0.15);
  margin-right: 5px; }
  

.submit {
  width: 130px;
  border-radius: 25px;
  -moz-border-radius: 25px;
  -webkit-border-radius: 25px;
  -o-border-radius: 25px;
  -ms-border-radius: 25px;
  text-transform: uppercase;
  font-size: 15px;
  cursor: pointer; }
        #backbtn{
            background:#00ec4f;
            float:left;
            
        }
        #backbtn:hover{
            background-color:  rgba(77, 84, 177, 0.804);
        }
        #logoutbtn{
            background: rgb(241, 49, 35);
            float:right;
    
        }
        #logoutbtn:hover{
            background-color:  rgba(77, 84, 177, 0.804);
        }
      
        #group{
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            background: rgba(77, 84, 177, 0.895);
            width: 60%;
            padding: 20px; 
            float:center; 
            color: #fff; 
        }
        #votebtn{
            padding: 5px;
    border-radius: 5px;
    background-color: rgb(111, 223, 245);
    color: rgb(13, 13, 13);
    font-size: 15px;
    height: 40px;
    width: 60px;
    
    float:left;
        }
        #mainpanel{
            padding: 10px;
        }
        #voted{
            padding: 4px;
    border-radius: 5px;
    height: 40px;
    background-color: green;
     color: rgb(13, 13, 13);
    font-size: 15px;
    width: 60px;
    float:left;
        }
      
                
        </style>
    
        <div id="mainpanel">
        <a href="../"> <button id="backbtn" class="form-submit submit">Back</button></a>
        <a href="logout.php"> <button id="logoutbtn" class="form-submit submit">Logout</button></a>
      <center> 
        <h1>RESULTS</h1>
    <div id="group">
        <?php
           if($_SESSION['groupsdata']){
                for($i=0; $i<count($groupsdata); $i++){
                    ?>
                    <div>
                       <img style="float:right" src="../uploads/<?php echo $groupsdata[$i]['photo'] ?>" height="100" width="100">
                       <b>Nominee Name:</b><?php echo $groupsdata[$i]['name'] ?><br><br>
                       <b>Votes:</b><?php echo $groupsdata[$i]['votes']?><br><br><br>
                       
                    </div>
                    <hr color="black">
                    <?php
                }
           }
           else{

           }
            
        ?>
    </div></center>
        </div>
    </div>
</body>
</html>